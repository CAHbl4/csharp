﻿namespace TransportManager.BL
{
    public class SeatType
    {
        public string Name { get; set; }
    }
}