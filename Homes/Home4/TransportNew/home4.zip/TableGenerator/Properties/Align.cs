﻿namespace TableGenerator
{
    /// <summary>
    ///     Перечисление которое хранит варианты выравнивания колонок
    /// </summary>
    public enum Align
    {
        Left,
        Center,
        Right
    }
}